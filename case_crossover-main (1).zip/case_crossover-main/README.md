# case_crossover
Code for simulations and numerical studies from Section 5 of A Formal Causal Interpretation of the Case-Crossover Design (https://arxiv.org/pdf/2005.00221.pdf).
